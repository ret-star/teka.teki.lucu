# Teka-Teki Lucu 😆

Sebuah koleksi game sederhana berisi pertanyaan-pertanyaan lucu untuk dimainkan bersama teman atau keluarga. Formatnya mirip kuis atau teka-teki ringan yang bikin ketawa!

## 🎮 Cara Main

1. Buka file `teka-teki-lucu.txt`.
2. Baca pertanyaannya.
3. Coba tebak jawabannya sebelum membuka jawaban di bawahnya.
4. Tertawa bareng 😄

## ✍️ Contoh

> **Pertanyaan**: Kenapa ayam menyeberang jalan?  
> **Jawaban**: Karena dia mau ke seberang 😆

## 📂 File

- `teka-teki-lucu.txt`: Daftar semua teka-teki lucu dan jawabannya.

## 💡 Cocok Untuk

- Ice breaking di kelas atau pertemuan
- Hiburan bareng teman
- Konten di media sosial

## 📜 Lisensi

Silakan digunakan dan dibagikan untuk hiburan, tapi tetap beri kredit ya kalau disebarkan 😊